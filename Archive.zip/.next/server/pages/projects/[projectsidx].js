(() => {
var exports = {};
exports.id = 864;
exports.ids = [864];
exports.modules = {

/***/ 635:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "NavPageStyles_container__EWWhi",
	"navContainer": "NavPageStyles_navContainer__P_OwF",
	"navBrandLogo": "NavPageStyles_navBrandLogo___dEy0",
	"navProject": "NavPageStyles_navProject__ekuzz",
	"projectLogo": "NavPageStyles_projectLogo__5wEwY"
};


/***/ }),

/***/ 5572:
/***/ ((module) => {

// Exports
module.exports = {
	"fadeInUp0": "ProjectPage002Styles_fadeInUp0__0bGsg",
	"fadeInUp": "ProjectPage002Styles_fadeInUp__7zMUs",
	"newsTitleBox": "ProjectPage002Styles_newsTitleBox__LEICy",
	"newsTitle": "ProjectPage002Styles_newsTitle__Sb5b8",
	"newsTitleH1": "ProjectPage002Styles_newsTitleH1__b98Az",
	"newsCredits": "ProjectPage002Styles_newsCredits__LkW4l",
	"creditsBoxWrapper": "ProjectPage002Styles_creditsBoxWrapper__auq7s",
	"creditsBox0": "ProjectPage002Styles_creditsBox0___r_ix"
};


/***/ }),

/***/ 3189:
/***/ ((module) => {

// Exports
module.exports = {
	"fadeInUp0": "ProjectPage01Styles_fadeInUp0__AsnrV",
	"fadeInUp": "ProjectPage01Styles_fadeInUp__q2xlD",
	"headlineNewsBox": "ProjectPage01Styles_headlineNewsBox__nxIaR",
	"headlineContent": "ProjectPage01Styles_headlineContent__6MGvM",
	"headlineWordBox": "ProjectPage01Styles_headlineWordBox__RDCq8",
	"headlineWord": "ProjectPage01Styles_headlineWord__QFch1",
	"wrapperText": "ProjectPage01Styles_wrapperText__vbOMc",
	"runLeftIn": "ProjectPage01Styles_runLeftIn__dbKF5",
	"test": "ProjectPage01Styles_test__rrP2N"
};


/***/ }),

/***/ 8390:
/***/ ((module) => {

// Exports
module.exports = {
	"fadeInUp0": "ProjectPage03Styles_fadeInUp0__Q3pyJ",
	"fadeInUp": "ProjectPage03Styles_fadeInUp__lo6Ng",
	"scaleIn": "ProjectPage03Styles_scaleIn___Bx0Y",
	"newsPage03Box": "ProjectPage03Styles_newsPage03Box__WDqYI",
	"page03VideoBox": "ProjectPage03Styles_page03VideoBox__L3Dg7",
	"videoBranding": "ProjectPage03Styles_videoBranding__7ga7T",
	"newsContent00": "ProjectPage03Styles_newsContent00__ysZwA",
	"newsContent01": "ProjectPage03Styles_newsContent01__d1AA_",
	"newsContent01Img": "ProjectPage03Styles_newsContent01Img__91__7",
	"brandImg": "ProjectPage03Styles_brandImg___4dU2",
	"newsContent01Text": "ProjectPage03Styles_newsContent01Text__kG0Q3",
	"test0": "ProjectPage03Styles_test0__FsQh5",
	"test0H1": "ProjectPage03Styles_test0H1__SGp5q",
	"test0H11": "ProjectPage03Styles_test0H11__j_rm5"
};


/***/ }),

/***/ 8090:
/***/ ((module) => {

// Exports
module.exports = {
	"fadeInUp0": "ProjectPage04Styles_fadeInUp0__SU1fS",
	"fadeInUp": "ProjectPage04Styles_fadeInUp__GOi9S",
	"newsContentTextPage04": "ProjectPage04Styles_newsContentTextPage04__kIObQ",
	"newsNextNews": "ProjectPage04Styles_newsNextNews__mmRTX",
	"nextNewsBackground": "ProjectPage04Styles_nextNewsBackground__jIhSK",
	"newsBackground": "ProjectPage04Styles_newsBackground__fClhY",
	"headlineNextNews": "ProjectPage04Styles_headlineNextNews__BAFht",
	"newsContentH1": "ProjectPage04Styles_newsContentH1__50gQe",
	"page02Container": "ProjectPage04Styles_page02Container__GZh9M",
	"page02Slider": "ProjectPage04Styles_page02Slider__3o_yY",
	"sliderContainer": "ProjectPage04Styles_sliderContainer__Za2Mj",
	"sliderItems": "ProjectPage04Styles_sliderItems__Z_qx6",
	"slideItem": "ProjectPage04Styles_slideItem__6RS5Y",
	"gridPicBox": "ProjectPage04Styles_gridPicBox__DrZyU",
	"gridBox": "ProjectPage04Styles_gridBox__mdBJv",
	"gridShow": "ProjectPage04Styles_gridShow__0e1It",
	"gridPic": "ProjectPage04Styles_gridPic__ek9oi",
	"plusIconBox": "ProjectPage04Styles_plusIconBox__3ain1",
	"plusImg": "ProjectPage04Styles_plusImg__bP2aB",
	"rotateIconPlus": "ProjectPage04Styles_rotateIconPlus__06BeS",
	"arrowLeftBox": "ProjectPage04Styles_arrowLeftBox__1PpLa",
	"arrowRightBox": "ProjectPage04Styles_arrowRightBox__hn9f_",
	"arrow": "ProjectPage04Styles_arrow__IiheM",
	"arrowImg": "ProjectPage04Styles_arrowImg__VTIRb",
	"slidePagination": "ProjectPage04Styles_slidePagination__X7ggs",
	"paginate": "ProjectPage04Styles_paginate__F7_LC",
	"slide-pagination": "ProjectPage04Styles_slide-pagination__kt4Q9",
	"item": "ProjectPage04Styles_item__O4dbK",
	"slider-container": "ProjectPage04Styles_slider-container__1rIAH",
	"testgrid": "ProjectPage04Styles_testgrid__sb6wU"
};


/***/ }),

/***/ 8805:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/arrowLeft.ea40196f.svg","height":24,"width":24});

/***/ }),

/***/ 2343:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/arrowRight.21b9a6eb.svg","height":24,"width":24});

/***/ }),

/***/ 181:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/plusicon.a293085a.svg","height":24,"width":24});

/***/ }),

/***/ 8165:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_NavPageStyles_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(635);
/* harmony import */ var _styles_NavPageStyles_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_styles_NavPageStyles_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_ProjectPage_ProjectPage01__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5699);
/* harmony import */ var _components_ProjectPage_ProjectPage02__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4160);
/* harmony import */ var _components_ProjectPage_ProjectPage03__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7854);
/* harmony import */ var _components_ProjectPage_ProjectPage04__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8350);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ProjectPage_ProjectPage01__WEBPACK_IMPORTED_MODULE_4__, _components_ProjectPage_ProjectPage02__WEBPACK_IMPORTED_MODULE_5__, _components_ProjectPage_ProjectPage03__WEBPACK_IMPORTED_MODULE_6__, _components_ProjectPage_ProjectPage04__WEBPACK_IMPORTED_MODULE_7__]);
([_components_ProjectPage_ProjectPage01__WEBPACK_IMPORTED_MODULE_4__, _components_ProjectPage_ProjectPage02__WEBPACK_IMPORTED_MODULE_5__, _components_ProjectPage_ProjectPage03__WEBPACK_IMPORTED_MODULE_6__, _components_ProjectPage_ProjectPage04__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




// import styles from "../../styles/NavPageStyles.module.css";






const ProjectPage = ({ projectsidx , data  })=>{
    // console.log("ssr ",data);
    const { 0: newsBigTitle , 1: setNewsBigTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: newsBigTitle1 , 1: setNewsBigTitle1  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: openTitle , 1: setOpenTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: subTitle , 1: setSubTitle  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: subTitle1 , 1: setSubTitle1  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: tagLine , 1: setTagLine  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: tagLine1 , 1: setTagLine1  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: category , 1: setCategory  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: content , 1: setContent  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: content1 , 1: setContent1  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: youtubeUrl , 1: setYoutubeUrl  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: bannerImg , 1: setBannerImg  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: img , 1: setImg  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: img1 , 1: setImg1  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: img2 , 1: setImg2  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: img3 , 1: setImg3  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: img4 , 1: setImg4  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: img5 , 1: setImg5  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: thumbnail , 1: setThumbNail  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    //
    const fetchData = ()=>{
        // if (projectsidx) {
        //   axios
        //     .get(`${urlNewsId}/${projectsidx}`)
        //     .then(({ data }) => {
        //       // console.log(data);
        //       setCategory(data[0].category);
        //       setNewsBigTitle(data[0].title);
        //       setNewsBigTitle1(data[0].title2);
        //       setOpenTitle(data[0].tagline21);
        //       setSubTitle(data[0].subtitle);
        //       setSubTitle1(data[0].subtitle2);
        //       setContent(data[0].content);
        //       setContent1(data[0].contetn2);
        //       setYoutubeUrl(data[0].youtubeLink);
        //       setTagLine(data[0].tagline11);
        //       setTagLine1(data[0].tagline12);
        //       setBannerImg(data[0].banner);
        //       setImg(data[0].img);
        //       setImg1(data[0].img1);
        //       setImg2(data[0].img2);
        //       setImg3(data[0].img3);
        //       setImg4(data[0].img4);
        //       setImg5(data[0].img5);
        //       setThumbNail(data[0].thumbnail);
        //       // setTageLine1(data[0].tagline2);
        //       // console.log(data[0]);
        //     })
        //     .catch((error) => {
        //       console.log(error);
        //     });
        // }
        setCategory(data.category);
        setNewsBigTitle(data.title);
        setNewsBigTitle1(data.title2);
        setOpenTitle(data.tagline21);
        setSubTitle(data.subtitle);
        setSubTitle1(data.subtitle2);
        setContent(data.content);
        setContent1(data.contetn2);
        setYoutubeUrl(data.youtubeLink);
        setTagLine(data.tagline11);
        setTagLine1(data.tagline12);
        setBannerImg(data.banner);
        setImg(data.img);
        setImg1(data.img1);
        setImg2(data.img2);
        setImg3(data.img3);
        setImg4(data.img4);
        setImg5(data.img5);
        setThumbNail(data.thumbnail);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        fetchData();
    }, [
        projectsidx
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProjectPage_ProjectPage01__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    title: newsBigTitle,
                    title1: newsBigTitle1,
                    category: category,
                    bannerImg: bannerImg
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_NavPageStyles_module_css__WEBPACK_IMPORTED_MODULE_8___default().container),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProjectPage_ProjectPage02__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            tagLine: tagLine,
                            tagLine1: tagLine1,
                            projectsidx: projectsidx
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProjectPage_ProjectPage03__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            openTitle: openTitle,
                            subTitle: subTitle,
                            youtubeUrl: youtubeUrl,
                            content: content,
                            img: img
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ProjectPage_ProjectPage04__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            subTitle1: subTitle1,
                            content1: content1,
                            img1: img1,
                            img2: img2,
                            img3: img3,
                            img4: img4,
                            img5: img5,
                            projectsidx: projectsidx
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProjectPage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5699:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var _styles_ProjectPage01Styles_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3189);
/* harmony import */ var _styles_ProjectPage01Styles_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_ProjectPage01Styles_module_css__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const ProjectPage01 = ({ title , title1 , category , bannerImg  })=>{
    const { 0: headline , 1: setHeadline  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: headline1 , 1: setHeadline1  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const headLineRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const isHeadLineIn = (0,framer_motion__WEBPACK_IMPORTED_MODULE_2__.useInView)(headLineRef);
    const headLineRef1 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const isHeadLineIn1 = (0,framer_motion__WEBPACK_IMPORTED_MODULE_2__.useInView)(headLineRef1);
    // console.log(title);
    const produceArray = ()=>{
        if (title) {
            let titleArr = title.split(" ");
            setHeadline(titleArr);
            if (title1) {
                let titleArr1 = title1.split(" ");
                setHeadline1(titleArr1);
            }
        }
    };
    const animationWords = ()=>{
        // console.log(headline);
        if (headline) {
            let b = headline.map((word, idx)=>{
                // console.log("123");
                let delay = {
                    animationDelay: `${idx / 5 + 0.5}s`
                };
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: isHeadLineIn ? `${(_styles_ProjectPage01Styles_module_css__WEBPACK_IMPORTED_MODULE_3___default().headlineWord)} ${(_styles_ProjectPage01Styles_module_css__WEBPACK_IMPORTED_MODULE_3___default().fadeInUp0)}` : (_styles_ProjectPage01Styles_module_css__WEBPACK_IMPORTED_MODULE_3___default().headlineWord),
                    style: delay,
                    children: word
                }, idx);
            });
            return b;
        }
    };
    const animationWords1 = ()=>{
        if (headline1) {
            let b = headline1.map((word, idx)=>{
                let delay = {
                    animationDelay: `${idx / 5 + 0.9}s`
                };
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                    className: isHeadLineIn1 ? `${(_styles_ProjectPage01Styles_module_css__WEBPACK_IMPORTED_MODULE_3___default().headlineWord)} ${(_styles_ProjectPage01Styles_module_css__WEBPACK_IMPORTED_MODULE_3___default().fadeInUp0)}` : (_styles_ProjectPage01Styles_module_css__WEBPACK_IMPORTED_MODULE_3___default().headlineWord),
                    style: delay,
                    children: word
                }, idx);
            });
            return b;
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        produceArray();
    }, [
        title
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_styles_ProjectPage01Styles_module_css__WEBPACK_IMPORTED_MODULE_3___default().headlineNewsBox),
            style: {
                background: `url(${bannerImg}) no-repeat center
    center/cover`
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_ProjectPage01Styles_module_css__WEBPACK_IMPORTED_MODULE_3___default().backgroundImgBox),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_styles_ProjectPage01Styles_module_css__WEBPACK_IMPORTED_MODULE_3___default().headlineContent),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_styles_ProjectPage01Styles_module_css__WEBPACK_IMPORTED_MODULE_3___default().headlineWordBox),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_ProjectPage01Styles_module_css__WEBPACK_IMPORTED_MODULE_3___default().wrapperText),
                                    ref: headLineRef,
                                    children: [
                                        " ",
                                        headline && animationWords()
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_styles_ProjectPage01Styles_module_css__WEBPACK_IMPORTED_MODULE_3___default().wrapperText),
                                    ref: headLineRef1,
                                    children: headline1 && animationWords1()
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_styles_ProjectPage01Styles_module_css__WEBPACK_IMPORTED_MODULE_3___default().clientShortInfo),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                children: category
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProjectPage01);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4160:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_ProjectPage002Styles_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5572);
/* harmony import */ var _styles_ProjectPage002Styles_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_ProjectPage002Styles_module_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ApiUrl_Api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4572);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// import styles from "../../styles/ProjectPage02Styles.module.css";







const ProjectPage02 = ({ tagLine , tagLine1 , projectsidx  })=>{
    // const router = useRouter();
    // const { projectsidx } = router.query;
    const { 0: line1 , 1: setLine1  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: line2 , 1: setLine2  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: contributorArr , 1: setContributorArr  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const arrWordRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const isArrWordIn = (0,framer_motion__WEBPACK_IMPORTED_MODULE_2__.useInView)(arrWordRef);
    const arrWordRef1 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const isArrWordIn1 = (0,framer_motion__WEBPACK_IMPORTED_MODULE_2__.useInView)(arrWordRef1);
    const getListContributor = ()=>{
        axios__WEBPACK_IMPORTED_MODULE_3___default().get(`${_ApiUrl_Api__WEBPACK_IMPORTED_MODULE_5__/* .urlListContributorIdPost */ .o1}/${projectsidx}`).then(({ data  })=>{
            // console.log(data);
            setContributorArr(data);
        }).catch((error)=>{
            console.log(error);
        });
    };
    const produceArray = ()=>{
        if (tagLine) {
            // console.log(tagLine1);
            let firstLine = tagLine.split(" ");
            setLine1(firstLine);
            if (tagLine1) {
                // console.log("123");
                let secondLine = tagLine1.split(" ");
                setLine2(secondLine);
            }
        }
    };
    const animationWords = ()=>{
        // console.log(line1);
        let b = line1.map((word, idx)=>{
            let delay = {
                animationDelay: `${idx / 5 + 0.5}s `
            };
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: isArrWordIn ? `${(_styles_ProjectPage002Styles_module_css__WEBPACK_IMPORTED_MODULE_6___default().fadeInUp0)}` : " ",
                style: delay,
                children: word
            }, idx);
        });
        return b;
    };
    const animationWords1 = ()=>{
        // console.log(line2);
        let b = line2.map((word, idx)=>{
            let delay = {
                animationDelay: `${idx / 5 + 1}s`
            };
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: isArrWordIn1 ? `${(_styles_ProjectPage002Styles_module_css__WEBPACK_IMPORTED_MODULE_6___default().fadeInUp0)}` : " ",
                style: delay,
                children: word
            }, idx);
        });
        return b;
    };
    const contributorList = ()=>{
        let b = contributorArr.map((contributor, idx)=>{
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                children: [
                    contributor.role,
                    " by : ",
                    contributor.contributorName
                ]
            }, idx);
        });
        return b;
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getListContributor();
        produceArray();
    }, [
        tagLine
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_styles_ProjectPage002Styles_module_css__WEBPACK_IMPORTED_MODULE_6___default().newsPage02Box),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_ProjectPage002Styles_module_css__WEBPACK_IMPORTED_MODULE_6___default().newsTitleBox),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_ProjectPage002Styles_module_css__WEBPACK_IMPORTED_MODULE_6___default().newsTitle),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_ProjectPage002Styles_module_css__WEBPACK_IMPORTED_MODULE_6___default().newsTitleH1),
                                ref: arrWordRef,
                                children: animationWords()
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_ProjectPage002Styles_module_css__WEBPACK_IMPORTED_MODULE_6___default().newsTitleH1),
                                ref: arrWordRef1,
                                children: animationWords1()
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_ProjectPage002Styles_module_css__WEBPACK_IMPORTED_MODULE_6___default().newsCredits),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_styles_ProjectPage002Styles_module_css__WEBPACK_IMPORTED_MODULE_6___default().newsCreditsWrapper),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: "credits"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_styles_ProjectPage002Styles_module_css__WEBPACK_IMPORTED_MODULE_6___default().creditsBoxWrapper),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_styles_ProjectPage002Styles_module_css__WEBPACK_IMPORTED_MODULE_6___default().creditsBox0),
                                            children: contributorList()
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_styles_ProjectPage002Styles_module_css__WEBPACK_IMPORTED_MODULE_6___default().creditsBox1)
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProjectPage02);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7854:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var next_future_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1608);
/* harmony import */ var next_future_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_future_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_ProjectPage03Styles_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8390);
/* harmony import */ var _styles_ProjectPage03Styles_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_ProjectPage03Styles_module_css__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const ProjectPage03 = ({ openTitle , subTitle , youtubeUrl , content , img  })=>{
    const { 0: subTitleAr , 1: setSubTitleAr  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const arrWordRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const isArrWordIn = (0,framer_motion__WEBPACK_IMPORTED_MODULE_2__.useInView)(arrWordRef);
    const produceArray = ()=>{
        if (subTitle) {
            let subTitleArr = subTitle.split("");
            // console.log(subTitleArr);
            setSubTitleAr(subTitleArr);
        }
    };
    const animationWords = ()=>{
        let b = subTitleAr.map((word, idx)=>{
            let delay = {
                animationDelay: `${idx / 5 + 0.5}s`
            };
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: isArrWordIn ? `${(_styles_ProjectPage03Styles_module_css__WEBPACK_IMPORTED_MODULE_4___default().fadeInUp0)}` : " ",
                style: delay,
                ref: arrWordRef,
                children: word
            }, idx);
        });
        return b;
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        produceArray();
    }, [
        subTitle
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            " ",
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_ProjectPage03Styles_module_css__WEBPACK_IMPORTED_MODULE_4___default().newsPage03Box),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_ProjectPage03Styles_module_css__WEBPACK_IMPORTED_MODULE_4___default().page03VideoBox),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_styles_ProjectPage03Styles_module_css__WEBPACK_IMPORTED_MODULE_4___default().videoBranding),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iframe", {
                                width: "100%",
                                height: "100%",
                                src: youtubeUrl,
                                title: "YouTube video player",
                                frameBorder: "0",
                                allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture;",
                                allowFullScreen: true
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_ProjectPage03Styles_module_css__WEBPACK_IMPORTED_MODULE_4___default().newsContentBox),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: `${(_styles_ProjectPage03Styles_module_css__WEBPACK_IMPORTED_MODULE_4___default().newsContent00)} ${(_styles_ProjectPage03Styles_module_css__WEBPACK_IMPORTED_MODULE_4___default().fadeTopDown)}`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: openTitle
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_ProjectPage03Styles_module_css__WEBPACK_IMPORTED_MODULE_4___default().newsContent01),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_ProjectPage03Styles_module_css__WEBPACK_IMPORTED_MODULE_4___default().newsContent01Img)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_ProjectPage03Styles_module_css__WEBPACK_IMPORTED_MODULE_4___default().newsContent01Text),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_ProjectPage03Styles_module_css__WEBPACK_IMPORTED_MODULE_4___default().test0),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: (_styles_ProjectPage03Styles_module_css__WEBPACK_IMPORTED_MODULE_4___default().test0H1),
                                                    ref: arrWordRef,
                                                    children: animationWords()
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    dangerouslySetInnerHTML: {
                                                        __html: content
                                                    }
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProjectPage03);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8350:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_imgs_arrowLeft_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8805);
/* harmony import */ var _public_imgs_arrowRight_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2343);
/* harmony import */ var _public_imgs_plusicon_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(181);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6197);
/* harmony import */ var next_future_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1608);
/* harmony import */ var next_future_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_future_image__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8090);
/* harmony import */ var _styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _ApiUrl_Api__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4572);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_5__]);
framer_motion__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];












const ProjectPage04 = ({ subTitle1 , content1 , img1 , img2 , img3 , img4 , img5 , projectsidx ,  })=>{
    const { 0: subTitleAr1 , 1: setSubTitleAr1  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: imgArr , 1: setImgArr  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: nextNews , 1: setNextNews  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: currentIdxNews , 1: setCurrentIdxNews  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const arrWordRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const isArrWordIn = (0,framer_motion__WEBPACK_IMPORTED_MODULE_5__.useInView)(arrWordRef);
    const getListNews = async ()=>{
        await axios__WEBPACK_IMPORTED_MODULE_7___default().get(_ApiUrl_Api__WEBPACK_IMPORTED_MODULE_9__/* .urlNews */ .rJ).then(({ data  })=>{
            let a = data.filter((data)=>{
                return data.deleted === "0";
            });
            // console.log(a);
            const findIdx = (e)=>e.postId === projectsidx;
            // console.log(a.findIndex(findIdx));
            let currentIdxNews = a.findIndex(findIdx);
            if (currentIdxNews >= 0) {
                let converToNum = parseInt(currentIdxNews);
                let b;
                if (converToNum === a.length - 1) {
                    b = a[0].postId;
                } else {
                    b = a[converToNum + 1].postId;
                }
                console.log(b);
                setCurrentIdxNews(b);
            }
        });
    };
    const fetchNextNews = async ()=>{
        if (currentIdxNews) {
            // console.log("currentIdxNews", currentIdxNews);
            await axios__WEBPACK_IMPORTED_MODULE_7___default().get(`${_ApiUrl_Api__WEBPACK_IMPORTED_MODULE_9__/* .urlNewsId */ .zS}/${currentIdxNews}`).then(({ data  })=>{
                // console.log(data);
                setNextNews(data[0]);
            });
        }
    };
    const produceArray = ()=>{
        if (subTitle1) {
            let subTitleArr1 = subTitle1.split("");
            // console.log(subTitleArr1);
            setSubTitleAr1(subTitleArr1);
            // console.log(typeof img);
            let imgArr = [];
            imgArr.push(img1);
            imgArr.push(img2);
            imgArr.push(img3);
            imgArr.push(img4);
            imgArr.push(img5);
            setImgArr(imgArr);
        }
    };
    const createSlideItems = ()=>{
        let b = imgArr.map((img, idx)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().slideItem),
                ref: refItem0,
                style: {
                    background: `url(${img}) no-repeat center center/cover`
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().item)
                })
            }, idx);
        });
        return b;
    };
    const animationWords = ()=>{
        let b = subTitleAr1.map((word, idx)=>{
            let delay = {
                animationDelay: `${idx / 5 + 0.5}s`
            };
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                className: isArrWordIn ? `${(_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().fadeInUp0)}` : " ",
                style: delay,
                children: word
            }, idx);
        });
        return b;
    };
    const { 0: isDown , 1: setIsDown  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: walk , 1: setWalk  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { 0: render , 1: setRender  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const sliderContainer = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const slider = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const startX = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(0);
    const check0 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(0);
    const check1 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(0);
    const refItem0 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const count = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(0);
    const x = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const plusBoxRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const arrowLeftBoxRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const arrowRightBoxRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const gridBoxRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const activeRender = ()=>{
        setRender(!render);
    };
    const mouseDown = (e)=>{
        setIsDown(true);
        sliderContainer.current.style.cursor = "grabbing";
        startX.current = slider.current.offsetLeft;
        check0.current = e.clientX;
    // console.log(slider.current.offsetLeft);
    // console.log(slider.current.children);
    };
    const mouseMove = (e)=>{
        handleMouseEnterInside(e);
        if (!isDown) return;
        x.current = e.clientX;
        // console.log("startX "+startX.current);
        // console.log(x.current)
        const test = e.clientX - check0.current;
        // console.log(startX.current + test);
        slider.current.style.transition = "";
        setWalk(startX.current + test);
        slider.current.style.left = `${walk}px`;
        //check left or right negative => right to left
        check1.current = x.current - check0.current;
    // console.log(check1.current)
    };
    const mouseUp = ()=>{
        sliderContainer.current.style.cursor = "grab";
        setIsDown(false);
        //swift from right to left
        const widthOfItem = refItem0.current.offsetWidth;
        if (check1.current < -50) {
            count.current = count.current - 1;
        }
        if (check1.current > 50) {
            count.current = count.current + 1;
        }
        if (count.current === -slider.current.children.length) {
            count.current = -(slider.current.children.length - 1);
        }
        if (count.current === 1) {
            count.current = 0;
        }
        slider.current.style.left = `${count.current * (widthOfItem + 120)}px`;
        slider.current.style.transition = "all 0.5s ease-in-out";
        setWalk(count.current * (widthOfItem + 120));
    };
    const mouseLeave = ()=>{
        setIsDown(false);
    };
    const tounchStart = (e)=>{
        setIsDown(true);
        sliderContainer.current.style.cursor = "grabbing";
        startX.current = slider.current.offsetLeft;
        check0.current = e.touches[0].clientX;
    // console.log(slider.current.offsetLeft);
    };
    const tounchMove = (e)=>{
        if (!isDown) return;
        x.current = e.touches[0].clientX;
        // console.log("startX "+startX.current);
        // console.log(x.current)
        const test = e.touches[0].clientX - check0.current;
        console.log(startX.current + test);
        slider.current.style.transition = "";
        slider.current.style.left = `${startX.current + test}px`;
        //check left or right negative => right to left
        check1.current = x.current - check0.current;
    // console.log(check1.current)
    };
    const TouchEnd = ()=>{
        sliderContainer.current.style.cursor = "grab";
        setIsDown(false);
        //swift from right to left
        const widthOfItem = refItem0.current.offsetWidth;
        setWalk(count.current * (widthOfItem + 120));
        if (check1.current < -50) {
            count.current = count.current - 1;
        }
        if (check1.current > 50) {
            count.current = count.current + 1;
        }
        if (count.current === -slider.current.children.length) {
            count.current = -(slider.current.children.length - 1);
        }
        if (count.current === 1) {
            count.current = 0;
        }
        slider.current.style.left = `${count.current * (widthOfItem + 120)}px`;
        slider.current.style.transition = "all 0.5s ease-in-out";
    };
    // handle mouse in side element to display dif icon
    const handleMouseEnterInside = (e)=>{
        e.stopPropagation();
        const widthOfItem = sliderContainer.current.offsetWidth;
        const heightOfItem = sliderContainer.current.offsetHeight;
        let offsetX = e.nativeEvent.offsetX;
        let offsetY = e.nativeEvent.offsetY;
        // console.log(offsetX);
        if (offsetX > 0 && offsetY > 0 && offsetX < widthOfItem && offsetY < heightOfItem) {
            if (document.body.clientWidth >= 950) {
                plusBoxRef.current.style.display = "inline-block";
                plusBoxRef.current.style.transform = `translate3d(${offsetX}px,${offsetY}px,0)`;
                arrowLeftBoxRef.current.style.display = "none";
                arrowRightBoxRef.current.style.display = "none";
            }
        }
    // if (offsetX < 10 || offsetX > widthOfItem - 10) {
    //   plusBoxRef.current.style.display = "none";
    // }
    };
    const handleMouseEnterOutside = (e)=>{
        let offsetX = e.nativeEvent.offsetX;
        let offsetY = e.nativeEvent.offsetY;
        if (document.body.clientWidth >= 950) {
            if (offsetX - sliderContainer.current.offsetLeft < 0) {
                plusBoxRef.current.style.display = "none";
                arrowRightBoxRef.current.style.display = "none";
                arrowLeftBoxRef.current.style.display = "inline-block";
                arrowLeftBoxRef.current.style.left = `${offsetX - 70}px`;
                arrowLeftBoxRef.current.style.top = `${offsetY - 50}px`;
            }
            // console.log(offsetX);
            if (offsetX - sliderContainer.current.offsetLeft > 0) {
                plusBoxRef.current.style.display = "none";
                arrowLeftBoxRef.current.style.display = "none";
                arrowRightBoxRef.current.style.display = "inline-block";
                arrowRightBoxRef.current.style.left = `${offsetX}px`;
                arrowRightBoxRef.current.style.top = `${offsetY - 50}px`;
            }
        }
        if (offsetY > 450) {
            arrowRightBoxRef.current.style.display = "none";
            arrowLeftBoxRef.current.style.display = "none";
            plusBoxRef.current.style.display = "none";
        }
    };
    const ClickMoveSlide = (e)=>{
        let offsetX = e.nativeEvent.offsetX;
        const widthOfItem = refItem0.current.offsetWidth;
        if (offsetX - sliderContainer.current.offsetLeft > 0 && count.current > -slider.current.children.length) {
            count.current = count.current - 1;
        }
        if (offsetX - sliderContainer.current.offsetLeft < 0 && count.current < 0) {
            count.current = count.current + 1;
        }
        if (count.current === -slider.current.children.length) {
            count.current = -(slider.current.children.length - 1);
        }
        if (count.current === 1) {
            count.current = 0;
        }
        setWalk(count.current * (widthOfItem + 120));
        slider.current.style.left = `${count.current * (widthOfItem + 120)}px`;
        slider.current.style.transition = "all 0.5s ease-in-out";
        adjustSlideItem();
    };
    const adjustSlideItem = ()=>{
        let a = slider.current.children;
        // console.log(a);
        for(let i = 0; i < a.length; i++){
            // console.log("123")
            if (count.current === -i) {
                a[i].style.transform = "rotate(0deg) translateY(0%) scale(1)";
                // console.log("a ", a);
                if (i < a.length - 1) {
                    // console.log("ett");
                    a[i + 1].style.transform = "rotate(4deg) translateY(5%) scale(1)";
                }
                if (i > 0) {
                    a[i - 1].style.transform = "rotate(-4deg) translateY(5%) scale(1)";
                }
            }
        }
    };
    const checkClientWidth = ()=>{
        // console.log(document.body.clientWidth);
        if (document.body.clientWidth < 950) {
            plusBoxRef.current.style.display = "none";
            arrowLeftBoxRef.current.style.display = "none";
            arrowRightBoxRef.current.style.display = "none";
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getListNews();
    }, [
        projectsidx
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        fetchNextNews();
    }, [
        currentIdxNews
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        produceArray();
    }, [
        subTitle1
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // console.log(count.current);
        // slider.current.style.left = `${count.current * (widthOfItem + 120)}px`;
        // slider.current.style.left = `${walk}px`;
        adjustSlideItem();
        activeRender();
        checkClientWidth();
    }, [
        walk,
        count
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            " ",
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().newsPage04Box),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().newsContentBox01),
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().newsContentTextPage04),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().newsContentH1),
                                    ref: arrWordRef,
                                    children: animationWords()
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    dangerouslySetInnerHTML: {
                                        __html: content1
                                    }
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().page02Container),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().gridPicBox),
                                onMouseMove: handleMouseEnterOutside,
                                ref: gridBoxRef,
                                onClick: ClickMoveSlide,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().gridBox)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().arrowLeftBox),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: `${(_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().plusIcon)} ${(_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().arrow)}`,
                                            ref: arrowLeftBoxRef,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_future_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                src: _public_imgs_arrowLeft_svg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                                                alt: "+",
                                                className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().arrowImg)
                                            })
                                        })
                                    }),
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().arrowRightBox),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: `${(_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().plusIcon)} ${(_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().arrow)}`,
                                            ref: arrowRightBoxRef,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_future_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                src: _public_imgs_arrowRight_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
                                                alt: "+",
                                                className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().arrowImg)
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().page02Slider),
                                ref: sliderContainer,
                                onTouchEnd: TouchEnd,
                                onTouchStart: tounchStart,
                                onTouchMove: tounchMove,
                                onMouseDown: mouseDown,
                                onMouseMove: mouseMove,
                                onMouseLeave: mouseLeave,
                                onMouseUp: mouseUp,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().plusIconBox),
                                        ref: plusBoxRef,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "plus-icon",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_future_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                src: _public_imgs_plusicon_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                                                alt: "+",
                                                className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().plusImg)
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().sliderContainer),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().sliderItems),
                                            ref: slider,
                                            children: createSlideItems()
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().newsNextNews),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Next project"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().nextNewsBackground),
                                children: nextNews && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                                    href: `/projects/${nextNews.postId}`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().newsBackground),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_styles_ProjectPage04Styles_module_css__WEBPACK_IMPORTED_MODULE_10___default().headlineNextNews),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    children: nextNews.title
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    children: nextNews.title1
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: nextNews.category
                                                })
                                            ]
                                        })
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProjectPage04);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5348:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Views_ProjectPage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8165);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ApiUrl_Api__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4572);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Views_ProjectPage__WEBPACK_IMPORTED_MODULE_3__]);
_Views_ProjectPage__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







async function getServerSideProps({ params  }) {
    // console.log(params.projectsidx, "312")
    let res;
    if (params.projectsidx !== "undefined" && params.projectsidx !== "requestProvider.js.map") {
        res = await axios__WEBPACK_IMPORTED_MODULE_5___default().get(`${_ApiUrl_Api__WEBPACK_IMPORTED_MODULE_6__/* .urlNewsId */ .zS}/${params.projectsidx}`).then(({ data  })=>{
            console.log(data[0]);
            return data[0];
        }).catch((error)=>{
            console.log(error);
        });
    }
    if (!res) {
        return {
            notFound: true
        };
    }
    return {
        props: {
            res
        }
    };
}
const projectsidx0 = ({ res  })=>{
    console.log(res);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { projectsidx  } = router.query;
    // console.log(projectsidx);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            " ",
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "/favicon.ico"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "stylesheet",
                        href: "https://fonts.googleapis.com/css?family=Montserrat"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: res.tagline21
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "keywords",
                        content: "Agency, Content,Marketing, KOL, Festival, Singer, Video, Art, Products"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "author",
                        content: "Trum Agency"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "canonical",
                        href: `/${res.postId}`
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:url",
                        content: `https://www.trumagency.com/projects/${res.postId}`
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:type",
                        content: "article"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:title",
                        content: res.title + " " + res.title2
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:description",
                        content: res.tagline21
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image",
                        content: res.thumbnail
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image:width",
                        content: "1200"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:image:height",
                        content: "630"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: res.title + " " + res.title2
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Views_ProjectPage__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                projectsidx: projectsidx,
                data: res
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (projectsidx0);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9646:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6197:
/***/ ((module) => {

"use strict";
module.exports = import("framer-motion");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,664,608,572], () => (__webpack_exec__(5348)));
module.exports = __webpack_exports__;

})();