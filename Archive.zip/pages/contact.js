import React from "react";
import Recuitment from "../components/Recuitment/Recuitment";
const recuitment = () => {
  return (
    <>
      <Recuitment />
    </>
  );
};

export default recuitment;
