export const urlAbout = "https://pagesmanagementapi.com/api/index/web-info";
export const editAbout =
  "https://pagesmanagementapi.com/api/admin/update/web-info";
export const urlNews = "https://pagesmanagementapi.com/api/index/post";
export const urlNewsId = "https://pagesmanagementapi.com/api/read/post";
export const urlEditNewsId =
  "https://pagesmanagementapi.com/api/admin/update/post";
export const urlAddNews =
  "https://pagesmanagementapi.com/api/admin/create/post";
export const urlDeleteNewsId =
  "https://pagesmanagementapi.com/api/admin/delete/post";
export const urlListContributorIdPost =
  "https://pagesmanagementapi.com/api/index/contributor";
export const urlEditIdContributor =
  "https://pagesmanagementapi.com/api/admin/update/contributor";
export const urlAddContributor =
  "https://pagesmanagementapi.com/api/admin/create/contributor";
export const urlDeleteContributor =
  "https://pagesmanagementapi.com/api/admin/delete/contributor";
