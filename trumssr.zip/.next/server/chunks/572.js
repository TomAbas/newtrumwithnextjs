"use strict";
exports.id = 572;
exports.ids = [572];
exports.modules = {

/***/ 4572:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BB": () => (/* binding */ urlAddNews),
/* harmony export */   "KP": () => (/* binding */ urlAddContributor),
/* harmony export */   "Pd": () => (/* binding */ urlDeleteNewsId),
/* harmony export */   "VQ": () => (/* binding */ editAbout),
/* harmony export */   "ZC": () => (/* binding */ urlEditNewsId),
/* harmony export */   "nN": () => (/* binding */ urlDeleteContributor),
/* harmony export */   "o1": () => (/* binding */ urlListContributorIdPost),
/* harmony export */   "rJ": () => (/* binding */ urlNews),
/* harmony export */   "t$": () => (/* binding */ urlAbout),
/* harmony export */   "zS": () => (/* binding */ urlNewsId)
/* harmony export */ });
/* unused harmony export urlEditIdContributor */
const urlAbout = "https://pagesmanagementapi.com/api/index/web-info";
const editAbout = "https://pagesmanagementapi.com/api/admin/update/web-info";
const urlNews = "https://pagesmanagementapi.com/api/index/post";
const urlNewsId = "https://pagesmanagementapi.com/api/read/post";
const urlEditNewsId = "https://pagesmanagementapi.com/api/admin/update/post";
const urlAddNews = "https://pagesmanagementapi.com/api/admin/create/post";
const urlDeleteNewsId = "https://pagesmanagementapi.com/api/admin/delete/post";
const urlListContributorIdPost = "https://pagesmanagementapi.com/api/index/contributor";
const urlEditIdContributor = "https://pagesmanagementapi.com/api/admin/update/contributor";
const urlAddContributor = "https://pagesmanagementapi.com/api/admin/create/contributor";
const urlDeleteContributor = "https://pagesmanagementapi.com/api/admin/delete/contributor";


/***/ })

};
;